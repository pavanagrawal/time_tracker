FactoryGirl.define do
  factory :allocation do
    project_id 1
    user_id 1
    start_date "2017-08-09"
    end_date "2017-08-09"
  end
end
