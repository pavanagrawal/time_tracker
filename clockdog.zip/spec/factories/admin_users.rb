FactoryGirl.define do
  factory :admin_user do
    
  end
end
