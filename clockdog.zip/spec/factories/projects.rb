FactoryGirl.define do
  factory :project do
    name "MyString"
  end
end
